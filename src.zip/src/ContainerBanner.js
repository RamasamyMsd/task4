import React from 'react'
import ContainerBannerElements from './ContainerBannerElements'
export default function ContainerBanner() {
  return (
    <>
     <div class="container1">
           
            <ContainerBannerElements 
            TopHeader="WE ARE SIXTEEN CREATIVE AGENCY" 
            Tagline="Based on Jakarta indonesia"
            
            
            />
            
    </div>
        </>
  )
}
