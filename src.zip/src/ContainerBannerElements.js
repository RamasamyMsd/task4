import React from 'react'

export default function ContainerBannerElements(ContainerProps) {
  return (
  <>
    <h3>{ContainerProps.TopHeader}</h3> 
     <h4>{ContainerProps.Tagline}</h4>
     
  </>
  )
}
