import React from 'react'

function ContainerImg() {
  return (

       <>
        <div className='container_img'>
            <div className='ImgDiv'>
            <img src='https://www.teahub.io/photos/full/67-671069_students-character-school-students.jpg'  alt="tttt"  style={{width:'100%',height:'800px'}} /> ////inline style 
            </div>
        
        </div>
   

         
       </>

  )
   
}

export default ContainerImg