export const ElementHeader = "Who We Are!";
export const textpara = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Nihil numquam vel temporibus dignissimos, molestiae quam officia odio assumenda consequuntur, modi rem corporis atque, nostrum harum hic. Porro distinctio vitae eaque? Lorem ipsum dolor sit amet consectetur adipisicing elit. Temporibus, ducimus perferendis, quaerat laboriosam architecto quos sequi obcaecati saepe, deserunt asperiores ad magni molestiae harum dignissimos repellat aliquid corrupti repudiandae porro. Lorem ipsum dolor, sit amet consectetur adipisicing elit. Odit quis dolores, repellendus nesciunt praesentium quisquam eveniet voluptate,  in fuga quaerat iure repudiandae at facilis tempora accusantium assumenda ipsa nemo dignissimos. Beatae hic tenetur repudiandae eos, voluptas nam? Impedit, suscipit. Aut minus iste vitae dicta mollitia unde, expedita fuga nobis at voluptatibus Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quod possimus ducimus ipsam blanditiis at deserunt doloribus asperiores? Ipsa distinctio unde harum molestias laboriosam minima nam, iste aspernatur, numquam dolores sed. Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatem deleniti earum consequuntur vero assumenda sit! Velit atque maiores, ut nihil repudiandae deleniti quibusdam! Omnis architecto sint quam dolore voluptatum numquam.";

export const button1text = "Learn More";

export const Flexheader = "GRAPHIC DESIGNER"
export const FlexPara ="Nemo enim ipsam voluptatem, quia voluptas sit, aspernatur aut odit aut fugit, sed quia Nemo enim ipsam voluptatem, quia voluptas sit, aspernatur aut odit aut fugit, sed quia"
export const Teamheader ="Meet Our Amazing Team"
export const Teampara ='"Asperious ea commodies eios a quo omnis esse"'
