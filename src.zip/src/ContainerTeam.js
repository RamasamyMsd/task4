import React from 'react'
import { Teamheader, Teampara } from './Container.constants';
function ContainerTeam() {
    return (
        <>
            <div className='container4'>
                <div className='content4'>
                    <h1>{Teamheader}</h1>
                    <p>{Teampara}</p>
                </div>
                <div className='ImageFlexBox'>
                    <div class="cardImageCnt">
                        <div className='card_img2'>
                            <img src="./siteimg/men1.jpeg" alt="user-image" />
                        </div>
                        <div className="card_info2">
                            <h2>John Doe</h2>
                            <h2>CEO&Founder</h2>
                        </div>
                        <div className="card_footer">
                            <img src="./siteimg/fb.png" id="fb" />
                            <img src="./siteimg/fb2.png" id="fb" />
                            <img src="./siteimg/fb3.png" id="fb" />
                        </div>
                    </div>
                    <div class="cardImageCnt">
                        <div className='card_img2'>
                            <img src="./siteimg/men1.jpeg" alt="user-image" />
                        </div>
                        <div className="card_info2">
                            <h2>John Doe</h2>
                            <h2>CEO&Founder</h2>
                        </div>
                        <div className="card_footer">
                            <img src="./siteimg/fb.png" id="fb" />
                            <img src="./siteimg/fb2.png" id="fb" />
                            <img src="./siteimg/fb3.png" id="fb" />
                        </div>
                    </div>
                    <div class="cardImageCnt">
                        <div className='card_img2'>
                            <img src="./siteimg/men1.jpeg" alt="user-image" />
                        </div>
                        <div className="card_info2">
                            <h2>John Doe</h2>
                            <h2>CEO&Founder</h2>
                        </div>
                        <div className="card_footer">
                            <img src="./siteimg/fb.png" id="fb" />
                            <img src="./siteimg/fb2.png" id="fb" />
                            <img src="./siteimg/fb3.png" id="fb" />
                        </div>
                    </div>
                    <div class="cardImageCnt">
                        <div className='card_img2'>
                            <img src="./siteimg/men1.jpeg" alt="user-image" />
                        </div>
                        <div className="card_info2">
                            <h2>John Doe</h2>
                            <h2>CEO&Founder</h2>
                        </div>
                        <div className="card_footer">
                            <img src="./siteimg/fb.png" id="fb" />
                            <img src="./siteimg/fb2.png" id="fb" />
                            <img src="./siteimg/fb3.png" id="fb" />
                        </div>
                    </div>




                </div>

            </div>





        </>
    )
}

export default ContainerTeam